let gameState = {
    stars: 0,
    level: 1,
    currentBuilding: null,
    currentChallenge: 0,
    challengeScore: 0,
    unlockedBuildings: ["letters"],
    currentDifficulty: "beginner", // مستوى الصعوبة الحالي
    challenges: {
        beginner: {
            letters: [
                {
                    question: "اختر الحروف من بين الكلمات التالية:",
                    options: ["في", "كتاب", "على", "قلم", "من", "بيت"],
                    correct: ["في", "على", "من"],
                    type: "multiple"
                },
                {
                    question: "أي من هذه حروف الجر؟",
                    options: ["إلى", "يكتب", "طالب", "تحت"],
                    correct: ["إلى", "تحت"],
                    type: "multiple"
                },
                {
                    question: "اختر حرف العطف:",
                    options: ["و", "كتب", "طاولة", "ف"],
                    correct: ["و", "ف"],
                    type: "multiple"
                }
            ],
            nouns: [
                {
                    question: "اختر الأسماء من بين الكلمات التالية:",
                    options: ["كتاب", "يكتب", "قلم", "يقرأ", "طالب", "يلعب"],
                    correct: ["كتاب", "قلم", "طالب"],
                    type: "multiple"
                },
                {
                    question: "أي من هذه أسماء الحيوانات؟",
                    options: ["قط", "شجرة", "كلب", "سيارة", "عصفور", "كتاب"],
                    correct: ["قط", "كلب", "عصفور"],
                    type: "multiple"
                },
                {
                    question: "اختر الأسماء المؤنثة:",
                    options: ["فاطمة", "أحمد", "مدرسة", "كتاب", "سيارة", "قلم"],
                    correct: ["فاطمة", "مدرسة", "سيارة"],
                    type: "multiple"
                }
            ],
            verbs: [
                {
                    question: "اختر الأفعال من بين الكلمات التالية:",
                    options: ["يكتب", "كتاب", "يقرأ", "قلم", "يلعب", "طالب"],
                    correct: ["يكتب", "يقرأ", "يلعب"],
                    type: "multiple"
                },
                {
                    question: "أي من هذه أفعال ماضية؟",
                    options: ["كتب", "يكتب", "قرأ", "يقرأ", "لعب", "يلعب"],
                    correct: ["كتب", "قرأ", "لعب"],
                    type: "multiple"
                },
                {
                    question: "اختر الأفعال المضارعة:",
                    options: ["يدرس", "درس", "يأكل", "أكل", "يجري", "جرى"],
                    correct: ["يدرس", "يأكل", "يجري"],
                    type: "multiple"
                }
            ],
            sentences: [
                {
                    question: "اختر الجملة الاسمية:",
                    options: ["الطالب مجتهد", "يكتب الطالب", "الكتاب مفيد", "يقرأ أحمد"],
                    correct: ["الطالب مجتهد", "الكتاب مفيد"],
                    type: "multiple"
                },
                {
                    question: "اختر الجملة الفعلية:",
                    options: ["يلعب الطفل", "الطفل نشيط", "تطير الطائرة", "الطائرة سريعة"],
                    correct: ["يلعب الطفل", "تطير الطائرة"],
                    type: "multiple"
                }
            ]
        },
        intermediate: {
            // قواعد الإعراب الأساسية
            irab: [
                {
                    question: "اختر الكلمة المرفوعة بالضمة:",
                    options: ["الكتابُ", "الكتابَ", "الكتابِ", "كتاباً"],
                    correct: ["الكتابُ"],
                    type: "single"
                },
                {
                    question: "اختر الكلمة المنصوبة بالفتحة:",
                    options: ["القلمُ", "القلمَ", "القلمِ", "قلمٌ"],
                    correct: ["القلمَ"],
                    type: "single"
                },
                {
                    question: "اختر الكلمة المجرورة بالكسرة:",
                    options: ["البيتُ", "البيتَ", "البيتِ", "بيتٌ"],
                    correct: ["البيتِ"],
                    type: "single"
                }
            ],
            // الجذور والأوزان الأساسية
            sarf: [
                {
                    question: "ما هو الجذر الثلاثي لكلمة \'كتابة\'؟",
                    options: ["كتب", "كتوب", "كاتب", "مكتوب"],
                    correct: ["كتب"],
                    type: "single"
                },
                {
                    question: "على أي وزن كلمة \'مدرسة\'؟",
                    options: ["مفعلة", "مفعل", "فعلة", "فعل"],
                    correct: ["مفعلة"],
                    type: "single"
                }
            ],
            // المبتدأ والخبر، الفاعل والمفعول
            nahw: [
                {
                    question: "حدد المبتدأ في الجملة: \'الشمس مشرقة\'.",
                    options: ["الشمس", "مشرقة"],
                    correct: ["الشمس"],
                    type: "single"
                },
                {
                    question: "حدد الفاعل في الجملة: \'قرأ الطالب الكتاب\'.",
                    options: ["قرأ", "الطالب", "الكتاب"],
                    correct: ["الطالب"],
                    type: "single"
                },
                {
                    question: "حدد المفعول به في الجملة: \'أكل الولد التفاحة\'.",
                    options: ["أكل", "الولد", "التفاحة"],
                    correct: ["التفاحة"],
                    type: "single"
                }
            ]
        },
        advanced: {
            // الإعراب التفصيلي والحالات الخاصة
            advanced_irab: [
                {
                    question: "أعرب كلمة \'مجتهد\' في جملة \'كان الطالب مجتهداً\'.",
                    options: ["خبر كان منصوب", "فاعل مرفوع", "مبتدأ مرفوع", "مفعول به منصوب"],
                    correct: ["خبر كان منصوب"],
                    type: "single"
                },
                {
                    question: "أعرب كلمة \'إن\' في جملة \'إن العلم نور\'.",
                    options: ["حرف ناسخ", "فعل ماض", "اسم مجرور", "حرف جر"],
                    correct: ["حرف ناسخ"],
                    type: "single"
                }
            ],
            // التصريف والميزان الصرفي
            advanced_sarf: [
                {
                    question: "ما هو وزن الفعل \'استفاد\'؟",
                    options: ["استفعل", "افتعل", "تفعل", "فعل"],
                    correct: ["استفعل"],
                    type: "single"
                },
                {
                    question: "صرف الفعل \'قال\' في المضارع مع الضمير \'هم\'.",
                    options: ["يقولون", "يقولان", "يقول", "قالوا"],
                    correct: ["يقولون"],
                    type: "single"
                }
            ],
            // الجمل المعقدة والتراكيب المتقدمة
            advanced_nahw: [
                {
                    question: "حدد نوع الجملة: \'العلم الذي ينفع صاحبه نور\'.",
                    options: ["جملة اسمية كبرى", "جملة فعلية صغرى", "جملة اسمية صغرى", "جملة فعلية كبرى"],
                    correct: ["جملة اسمية كبرى"],
                    type: "single"
                }
            ]
        },
        expert: {
            // بحور الشعر والقافية
            arood: [
                {
                    question: "ما هو البحر الشعري لبيت \'إذا الشعب يوما أراد الحياة فلا بد أن يستجيب القدر\'؟",
                    options: ["البحر الطويل", "البحر البسيط", "البحر الكامل", "البحر الوافر"],
                    correct: ["البحر الكامل"],
                    type: "single"
                }
            ],
            // البديع والمحسنات البديعية
            balagha: [
                {
                    question: "حدد نوع المحسن البديعي في \'وجوه يومئذ ناضرة إلى ربها ناظرة\'.",
                    options: ["جناس تام", "طباق", "مقابلة", "سجع"],
                    correct: ["جناس تام"],
                    type: "single"
                }
            ]
        }
    }
};

// عناصر DOM
const screens = {
    start: document.getElementById("start-screen"),
    game: document.getElementById("game-screen"),
    challenge: document.getElementById("challenge-screen"),
    success: document.getElementById("success-screen"),
    difficulty: document.getElementById("difficulty-selection-screen")
};

const elements = {
    startBtn: document.getElementById("start-btn"),
    backBtn: document.getElementById("back-btn"),
    starCount: document.getElementById("star-count"),
    level: document.getElementById("level"),
    guideText: document.getElementById("guide-text"),
    challengeTitle: document.getElementById("challenge-title"),
    challengeArea: document.getElementById("challenge-area"),
    challengeScore: document.getElementById("challenge-score"),
    checkAnswer: document.getElementById("check-answer"),
    nextChallenge: document.getElementById("next-challenge"),
    feedbackArea: document.getElementById("feedback-area"),
    feedbackMessage: document.getElementById("feedback-message"),
    successMessage: document.getElementById("success-message"),
    earnedStars: document.getElementById("earned-stars"),
    continueBtn: document.getElementById("continue-btn"),
    difficultySelectionBtn: document.getElementById("difficulty-selection-btn"),
    difficultyButtons: document.querySelectorAll(".difficulty-btn"),
    guideName: document.getElementById("guide-name") // عنصر جديد لاسم المرشد
};

// إضافة عناصر الصوت
const audio = {
    correct: new Audio("sounds/win.wav"), 
    incorrect: new Audio("sounds/lose.wav"), 
    win: new Audio("sounds/win.wav") // صوت الفوز بالمرحلة
};

// الرسائل التوجيهية
const guideMessages = {
    letters: "ممتاز! تعلمت الحروف. الآن يمكنك دخول حي الأسماء!",
    nouns: "رائع! أتقنت الأسماء. ساحة الأفعال في انتظارك!",
    verbs: "عظيم! تعلمت الأفعال. حديقة الجمل مفتوحة الآن!",
    sentences: "مبروك! أصبحت خبيراً في قواعد اللغة العربية!",
    irab: "أحسنت في الإعراب! استعد لتحديات الصرف!",
    sarf: "مذهل! أتقنت الصرف. البلاغة تنتظرك!",
    nahw: "رائع! أتقنت النحو. حان وقت التحديات المتقدمة!",
    advanced_irab: "ممتاز! الإعراب المتقدم في متناول يدك!",
    advanced_sarf: "أتقنت الصرف المتقدم! النحو المتقدم ينتظرك!",
    advanced_nahw: "أحسنت! أنت الآن خبير في النحو المتقدم!",
    arood: "مذهل! أتقنت العروض. حان وقت البلاغة!",
    balagha: "رائع! أتقنت البلاغة. أنت الآن خبير في اللغة العربية!",
    default: "اختر أحد المباني لتبدأ التعلم!"
};

// بدء اللعبة
function initGame() {
    showScreen("start");
    updateUI();
    elements.guideName.textContent = "الأستاذ جمال"; // تعيين اسم المرشد
    
    // إضافة مستمعي الأحداث
    elements.startBtn.addEventListener("click", () => showScreen("game"));
    elements.backBtn.addEventListener("click", () => showScreen("game"));
    elements.checkAnswer.addEventListener("click", checkAnswer);
    elements.nextChallenge.addEventListener("click", nextChallenge);
    elements.continueBtn.addEventListener("click", () => showScreen("game"));
    
    // إضافة مستمعي أحداث المباني
    document.querySelectorAll(".building").forEach(building => {
        building.addEventListener("click", () => {
            const buildingType = building.dataset.building;
            if (gameState.unlockedBuildings.includes(buildingType)) {
                startChallenge(buildingType);
            } else {
                elements.guideText.textContent = "عليك إكمال التحديات السابقة أولاً لفتح هذا المبنى!";
            }
        });
    });

    // إضافة مستمعي أحداث أزرار الصعوبة
    elements.difficultySelectionBtn.addEventListener("click", () => showScreen("difficulty"));
    elements.difficultyButtons.forEach(button => {
        button.addEventListener("click", () => {
            gameState.currentDifficulty = button.dataset.difficulty;
            // إعادة تعيين المباني المفتوحة بناءً على الصعوبة
            if (gameState.currentDifficulty === "beginner") {
                gameState.unlockedBuildings = ["letters"];
            } else if (gameState.currentDifficulty === "intermediate") {
                gameState.unlockedBuildings = ["irab"];
            } else if (gameState.currentDifficulty === "advanced") {
                gameState.unlockedBuildings = ["advanced_irab"];
            } else if (gameState.currentDifficulty === "expert") {
                gameState.unlockedBuildings = ["arood"];
            }
            showScreen("game");
            updateUI();
        });
    });
}

// عرض شاشة معينة
function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove("active"));
    screens[screenName].classList.add("active");
}

// تحديث واجهة المستخدم
function updateUI() {
    elements.starCount.textContent = gameState.stars;
    elements.level.textContent = gameState.level;
    
    // تحديث حالة المباني
    document.querySelectorAll(".building").forEach(building => {
        const buildingType = building.dataset.building;
        const statusElement = building.querySelector(".building-status");
        
        // إخفاء المباني التي لا تنتمي لمستوى الصعوبة الحالي
        const difficultyBuildings = Object.keys(gameState.challenges[gameState.currentDifficulty]);
        if (!difficultyBuildings.includes(buildingType)) {
            building.style.display = "none";
            return;
        } else {
            building.style.display = "block";
        }

        if (gameState.unlockedBuildings.includes(buildingType)) {
            building.classList.remove("locked");
            statusElement.textContent = "متاح";
            statusElement.className = "building-status unlocked";
        } else {
            building.classList.add("locked");
            statusElement.textContent = "مغلق";
            statusElement.className = "building-status locked";
        }
    });
    
    // تحديث رسالة المرشد
    const lastUnlocked = gameState.unlockedBuildings[gameState.unlockedBuildings.length - 1];
    elements.guideText.textContent = guideMessages[lastUnlocked] || guideMessages.default;
}

// بدء تحدي
function startChallenge(buildingType) {
    gameState.currentBuilding = buildingType;
    gameState.currentChallenge = 0;
    gameState.challengeScore = 0;
    
    const buildingNames = {
        letters: "تحدي الحروف",
        nouns: "تحدي الأسماء",
        verbs: "تحدي الأفعال",
        sentences: "تحدي الجمل",
        irab: "تحدي الإعراب",
        sarf: "تحدي الصرف",
        nahw: "تحدي النحو",
        advanced_irab: "تحدي الإعراب المتقدم",
        advanced_sarf: "تحدي الصرف المتقدم",
        advanced_nahw: "تحدي النحو المتقدم",
        arood: "تحدي العروض",
        balagha: "تحدي البلاغة"
    };
    
    elements.challengeTitle.textContent = buildingNames[buildingType];
    elements.challengeScore.textContent = `النقاط: ${gameState.challengeScore}`;
    
    showScreen("challenge");
    loadChallenge();
}

// تحميل تحدي
function loadChallenge() {
    const challenges = gameState.challenges[gameState.currentDifficulty][gameState.currentBuilding];
    const challenge = challenges[gameState.currentChallenge];
    
    if (!challenge) {
        completeBuilding();
        return;
    }
    
    elements.challengeArea.innerHTML = `
        <div class="challenge-question">${challenge.question}</div>
        <div class="word-options">
            ${challenge.options.map(option => 
                `<div class="word-option" data-word="${option}">${option}</div>`
            ).join("")}
        </div>
    `;
    
    // إضافة مستمعي أحداث للخيارات
    document.querySelectorAll(".word-option").forEach(option => {
        option.addEventListener("click", () => {
            if (challenge.type === "single") {
                // إلغاء تحديد جميع الخيارات الأخرى في وضع الاختيار الفردي
                document.querySelectorAll(".word-option").forEach(opt => opt.classList.remove("selected"));
            }
            option.classList.toggle("selected");
        });
    });
    
    elements.checkAnswer.style.display = "inline-block";
    elements.nextChallenge.style.display = "none";
    elements.feedbackMessage.textContent = "";
    elements.feedbackMessage.className = "";
}

// فحص الإجابة
function checkAnswer() {
    const challenges = gameState.challenges[gameState.currentDifficulty][gameState.currentBuilding];
    const challenge = challenges[gameState.currentChallenge];
    const selectedOptions = Array.from(document.querySelectorAll(".word-option.selected"))
        .map(option => option.dataset.word);
    
    const correctAnswers = challenge.correct;
    let isCorrect;

    if (challenge.type === "single") {
        isCorrect = selectedOptions.length === 1 && selectedOptions[0] === correctAnswers[0];
    } else {
        isCorrect = selectedOptions.length === correctAnswers.length && 
            selectedOptions.every(answer => correctAnswers.includes(answer)) &&
            correctAnswers.every(answer => selectedOptions.includes(answer));
    }
    
    // تلوين الإجابات
    document.querySelectorAll(".word-option").forEach(option => {
        const word = option.dataset.word;
        if (correctAnswers.includes(word)) {
            option.classList.add("correct");
        } else if (option.classList.contains("selected")) {
            option.classList.add("incorrect");
        }
        option.style.pointerEvents = "none";
    });
    
    if (isCorrect) {
        gameState.challengeScore += 10;
        elements.feedbackMessage.textContent = "🎉 إجابة صحيحة! أحسنت!";
        elements.feedbackMessage.className = "feedback-correct";
        audio.correct.play(); // تشغيل صوت الإجابة الصحيحة
        elements.nextChallenge.style.display = "inline-block"; // إظهار زر التحدي التالي فقط عند الإجابة الصحيحة
    } else {
        elements.feedbackMessage.textContent = "❌ إجابة خاطئة. حاول مرة أخرى!";
        elements.feedbackMessage.className = "feedback-incorrect";
        audio.incorrect.play(); // تشغيل صوت الإجابة الخاطئة
        elements.nextChallenge.style.display = "none"; // إخفاء زر التحدي التالي حتى يتم الإجابة الصحيحة
    }
    
    elements.challengeScore.textContent = `النقاط: ${gameState.challengeScore}`;
    elements.checkAnswer.style.display = "inline-block"; // إبقاء زر التحقق مرئياً لإعادة المحاولة
}

// التحدي التالي
function nextChallenge() {
    const challenges = gameState.challenges[gameState.currentDifficulty][gameState.currentBuilding];
    if (gameState.currentChallenge < challenges.length - 1) {
        gameState.currentChallenge++;
        loadChallenge();
    } else {
        completeBuilding(); // إذا انتهت جميع التحديات في المبنى الحالي
    }
}

// إكمال مبنى
function completeBuilding() {
    const earnedStars = Math.max(5, gameState.challengeScore);
    gameState.stars += earnedStars;
    audio.win.play(); // تشغيل صوت الفوز بالمرحلة
    
    // فتح المبنى التالي بناءً على مستوى الصعوبة الحالي
    const buildingOrder = Object.keys(gameState.challenges[gameState.currentDifficulty]);
    const currentIndex = buildingOrder.indexOf(gameState.currentBuilding);
    if (currentIndex < buildingOrder.length - 1) {
        const nextBuilding = buildingOrder[currentIndex + 1];
        if (!gameState.unlockedBuildings.includes(nextBuilding)) {
            gameState.unlockedBuildings.push(nextBuilding);
        }
    } else {
        // إذا أكمل اللاعب جميع المباني في مستوى الصعوبة الحالي، يفتح المستوى التالي
        const difficultyOrder = ["beginner", "intermediate", "advanced", "expert"];
        const currentDifficultyIndex = difficultyOrder.indexOf(gameState.currentDifficulty);
        if (currentDifficultyIndex < difficultyOrder.length - 1) {
            const nextDifficulty = difficultyOrder[currentDifficultyIndex + 1];
            gameState.currentDifficulty = nextDifficulty;
            gameState.unlockedBuildings = [Object.keys(gameState.challenges[nextDifficulty])[0]]; // يفتح أول مبنى في الصعوبة الجديدة
            gameState.level++; // يزيد المستوى عند الانتقال لصعوبة جديدة
        }
    }
    
    // رفع المستوى
    if (gameState.stars >= gameState.level * 20) {
        gameState.level++;
    }
    
    elements.earnedStars.textContent = earnedStars;
    elements.successMessage.textContent = `لقد أكملت ${getBuildingName(gameState.currentBuilding)} بنجاح!`;
    
    showScreen("success");
    updateUI();
}

// الحصول على اسم المبنى
function getBuildingName(buildingType) {
    const names = {
        letters: "بيت الحروف",
        nouns: "حي الأسماء",
        verbs: "ساحة الأفعال",
        sentences: "حديقة الجمل",
        irab: "قصر الإعراب",
        sarf: "مكتبة الصرف",
        nahw: "برج النحو",
        advanced_irab: "أكاديمية الإعراب المتقدم",
        advanced_sarf: "معهد الصرف",
        advanced_nahw: "مختبر النحو",
        arood: "جامعة العروض",
        balagha: "مرصد البلاغة"
    };
    return names[buildingType];
}

// بدء اللعبة عند تحميل الصفحة
document.addEventListener("DOMContentLoaded", initGame);


